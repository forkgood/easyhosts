hosts.txt - 常用网站增强规则，适用于Android/iOS/Windows/Mac OS/Linux等各种操作系统
hosts-noad.txt - 常用网站增强规则+去广告，适用于Android/iOS/Windows/Mac OS/Linux等各种操作系统

dnsmasq.txt - 根据hosts规则转换的dnsmasq 规则，适用于 Linux 及 OpenWrt 等系统
dnsmasq-noad.txt - 根据hosts规则转换的dnsmasq 规则+去广告，适用于 Linux/OpenWrt 等环境系统

surge.txt - 根据hosts规则转换的Surge 规则，适用于Surge/Shadowrocket等各种代理软件
surge.txt - 根据hosts规则转换的Surge 规则+去广告，适用于Surge/Shadowrocket等各种代理软件

README.txt - 本文件，说明文档